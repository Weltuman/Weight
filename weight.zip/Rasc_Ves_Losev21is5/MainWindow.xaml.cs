﻿using System;                                                          //                           //
using System.Windows;                                                  //                           //
namespace Rasc_Ves_Losev21is5                                          //                           //
{                                                                      //                           //
    public partial class MainWindow : Window                           //                           //
    {                                                                  //                           //
         string caption = "Оповещение";                                //                           //
        MessageBoxButton button = MessageBoxButton.OK;                 //                           //
        MessageBoxImage icon = MessageBoxImage.Information;            //                           //
        MessageBoxResult result;                                       //Информационное оповещение  //
                                                                       //                           //
        int Rost = 0;                                                  //Вводимый Рост              //
        int Ves = 0;                                                   //Вводимый Вес               //
        int Vozrast = 0;                                               //Вводимый Воозраст          //
        public MainWindow()                                            //                           //
        {                                                              //                           //
            InitializeComponent();                                     //                           //
        }                                                              //                           //
        private void Itog_Click(object sender, RoutedEventArgs e)      //                           //
        {                                                              //                           //
            Rost = Convert.ToInt32(Rost_Tela.Text);                    // Присвоение                //
            Ves = Convert.ToInt32(Ves_Tela.Text);                      // Присвоение                //
            Vozrast = Convert.ToInt32(Vozrast_Celoveka.Text);          // Присвоение                //
                                                                       //                           //
                                                                       //                           //
            //Формула Кетле                                            //                           //
            Ketle.Text = (Ves / ((Rost * Rost)/10000.0)).ToString();   // Формула Кетле             //
            int znacen_vozr = Convert.ToInt32(Vozrast);                // Присвоение                //
            var znacen_Ket = Convert.ToDouble(Ketle.Text);             // Присвоение                //
                                                                       //                           //
            //Формула Броко                                            //                           //
            if (znacen_vozr < 40)                                      // Младше 40 лет             //
            {                                                          //                           //
                Broko1.Text = (Rost - 110).ToString();                 // Формула , вывод двнных    //
                Broko2.Text = "Вам меньше 40 лет";                     // Вывод текста              //
            }                                                          //                           //
            else if (znacen_vozr > 40)                                 // Старше 40 лет             //
            {                                                          //                           //
                Broko1.Text = (Rost - 100).ToString();                 // Формула , вывод двнных    //
                Broko2.Text = "Вам Больше 40 лет";                     // Вывод текста              //
            }                                                          //                           //
            Broko3.Text = "Ваша норма веса";                           // Вывод текста              //
            var znacen_vesBr = Convert.ToDouble(Broko1.Text);          // Присвоение                //
//////////////////////////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                                                       //                                    //
            if (znacen_vesBr > Ves && znacen_Ket <= 18.5)                                                                                              //Проверка условий                    //
            {                                                                                                                                          //                                    //
                string messageBoxText = $"У вас недовес тела на = {Math.Abs(znacen_vesBr - Ves)} кг\nДифицит массы тела";                              //Параментры для уведомления          //
                result = MessageBox.Show(messageBoxText, caption, button, icon);                                                                       //Возвращение Результатов уведомления //
            }                                                                                                                                          //                                    //
            else if (Ves.ToString() == znacen_vesBr.ToString() && znacen_Ket <= 18.5)                                                                  //Проверка условий                    //
            {                                                                                                                                          //                                    //
                string messageBoxText = $"У вас оптимальный вес тела\nДифицит массы тела";                                                             //Параментры для уведомления          //
                result = MessageBox.Show(messageBoxText, caption, button, icon);                                                                       //Возвращение Результатов уведомления //
            }                                                                                                                                          //                                    //
            else if (znacen_vesBr < Ves && znacen_Ket <= 18.5)                                                                                         //Проверка условий                    //
            {                                                                                                                                          //                                    //
                string messageBoxText = $"Ваш вес привышает оптимальный на = {Math.Abs(Ves - znacen_vesBr)} кг\nДифицит массы тела";                   //Параментры для уведомления          //
                result = MessageBox.Show(messageBoxText, caption, button, icon);                                                                       //Возвращение Результатов уведомления //
            }                                                                                                                                          //                                    //
                                                                                                                                                       //                                    //
                                                                                                                                                       //                                    //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                                                       //                                    //
                                                                                                                                                       //                                    //
            else if (znacen_vesBr > Ves && znacen_Ket <= 18.5 && znacen_Ket < 24.9)                                                                    //Проверка условий                    //
            {                                                                                                                                          //                                    //
                string messageBoxText = $"У вас недовес тела на = {Math.Abs(znacen_vesBr - Ves)} кг\nНормальная масса тела";                           //Параментры для уведомления          //
                result = MessageBox.Show(messageBoxText, caption, button, icon);                                                                       //Возвращение Результатов уведомления //
            }                                                                                                                                          //                                    //
            else if (Ves.ToString() == znacen_vesBr.ToString() && znacen_Ket > 18.5 && znacen_Ket < 24.9)                                              //Проверка условий                    //
            {                                                                                                                                          //                                    //
                string messageBoxText = "У вас оптимальный вес тела\nНормальная масса тела";                                                           //Параментры для уведомления          //
                result = MessageBox.Show(messageBoxText, caption, button, icon);                                                                       //Возвращение Результатов уведомления //
            }                                                                                                                                          //                                    //
            else if (znacen_vesBr < Ves && znacen_Ket > 18.5 && znacen_Ket < 24.9)                                                                     //Проверка условий                    //
            {                                                                                                                                          //                                    //
                string messageBoxText = $"Ваш вес привышен оптимальный на = {Math.Abs(Ves - znacen_vesBr)} кг\nНормальная масса тела";                 //Параментры для уведомления          //
                result = MessageBox.Show(messageBoxText, caption, button, icon);                                                                       //Возвращение Результатов уведомления //
            }                                                                                                                                          //                                    //
                                                                                                                                                       //                                    //
                                                                                                                                                       //                                    //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                                                       //                                    //
                                                                                                                                                       //                                    //
            else if (znacen_vesBr > Ves && znacen_Ket > 25 && znacen_Ket < 29.9)                                                                       //Проверка условий                    //
            {                                                                                                                                          //                                    //
                string messageBoxText = $"У вас недовес тела на = {Math.Abs(znacen_vesBr - Ves)} кг\nИзбыточная масса тела(преожирение)";              //Параментры для уведомления          //
                result = MessageBox.Show(messageBoxText, caption, button, icon);                                                                       //Возвращение Результатов уведомления //
            }                                                                                                                                          //                                    //
            else if (Ves.ToString() == znacen_vesBr.ToString() && znacen_Ket > 25 && znacen_Ket < 29.9)                                                //Проверка условий                    //
            {                                                                                                                                          //                                    //
                string messageBoxText = "У вас оптимальный вес тела\nИзбыточная масса тела(преожирение)";                                              //Параментры для уведомления          //
                result = MessageBox.Show(messageBoxText, caption, button, icon);                                                                       //Возвращение Результатов уведомления //
            }                                                                                                                                          //                                    //
            else if (znacen_vesBr < Ves && znacen_Ket > 25 && znacen_Ket < 29.9)                                                                       //Проверка условий                    //
            {                                                                                                                                          //                                    //
                string messageBoxText = $"Ваш вес привышает оптимальный на = {Math.Abs(Ves - znacen_vesBr)} кг\nИзбыточная масса тела(преожирение)";   //Параментры для уведомления          //
                result = MessageBox.Show(messageBoxText, caption, button, icon);                                                                       //Возвращение Результатов уведомления //
            }                                                                                                                                          //                                    //
                                                                                                                                                       //                                    //
                                                                                                                                                       //                                    //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                                                       //                                    //
                                                                                                                                                       //                                    //
            else if (znacen_vesBr > Ves && znacen_Ket > 30 && znacen_Ket < 34.9)                                                                       //Проверка условий                    //
            {                                                                                                                                          //                                    //
                string messageBoxText = $"У вас недовес тела на = {Math.Abs(znacen_vesBr - Ves)} кг\nОжирение 1 степени";                              //Параментры для уведомления          //
                result = MessageBox.Show(messageBoxText, caption, button, icon);                                                                       //Возвращение Результатов уведомления //
            }                                                                                                                                          //                                    //
            else if (Ves.ToString() == znacen_vesBr.ToString() && znacen_Ket > 30 && znacen_Ket < 34.9)                                                //Проверка условий                    //
            {                                                                                                                                          //                                    //
                string messageBoxText = "У вас оптимальный вес тела\nОжирение 1 степени";                                                              //Параментры для уведомления          //
                result = MessageBox.Show(messageBoxText, caption, button, icon);                                                                       //Возвращение Результатов уведомления //
            }                                                                                                                                          //                                    //
            else if (znacen_vesBr < Ves && znacen_Ket > 30 && znacen_Ket < 34.9)                                                                       //Проверка условий                    //
            {                                                                                                                                          //                                    //
                string messageBoxText = $"Ваш вес привышает оптимальный на = {Math.Abs(Ves - znacen_vesBr)} кг\nОжирение 1 степени";                   //Параментры для уведомления          //
                result = MessageBox.Show(messageBoxText, caption, button, icon);                                                                       //Возвращение Результатов уведомления //
            }                                                                                                                                          //                                    //
                                                                                                                                                       //                                    //
                                                                                                                                                       //                                    //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                                                       //                                    //
                                                                                                                                                       //                                    //
            else if (znacen_vesBr > Ves && znacen_Ket > 35 && znacen_Ket < 39.9)                                                                       //Проверка условий                    //
            {                                                                                                                                          //                                    //
                string messageBoxText = $"У вас недовес тела на = {Math.Abs(znacen_vesBr - Ves)} кг\nОжирение 2 степени";                              //Параментры для уведомления          //
                result = MessageBox.Show(messageBoxText, caption, button, icon);                                                                       //Возвращение Результатов уведомления //
            }                                                                                                                                          //                                    //
            else if (Ves.ToString() == znacen_vesBr.ToString() && znacen_Ket > 35 && znacen_Ket < 39.9)                                                //Проверка условий                    //
            {                                                                                                                                          //                                    //
                string messageBoxText = "У вас оптимальный вес тела\nОжирение 2 степени";                                                              //Параментры для уведомления          //
                result = MessageBox.Show(messageBoxText, caption, button, icon);                                                                       //Возвращение Результатов уведомления //
            }                                                                                                                                          //                                    //
            else if (znacen_vesBr < Ves && znacen_Ket > 35 && znacen_Ket < 39.9)                                                                       //Проверка условий                    //
            {                                                                                                                                          //                                    //
                string messageBoxText = $"Ваш вес привышает оптимальный на = {Math.Abs(Ves - znacen_vesBr)} кг\nОжирение 2 степени";                   //Параментры для уведомления          //
                result = MessageBox.Show(messageBoxText, caption, button, icon);                                                                       //Возвращение Результатов уведомления //
            }                                                                                                                                          //                                    //
                                                                                                                                                       //                                    //
                                                                                                                                                       //                                    //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                                                       //                                    //
                                                                                                                                                       //                                    //
            else if (znacen_vesBr > Ves && znacen_Ket >= 40)                                                                                           //Проверка условий                    //
            {                                                                                                                                          //                                    //
                string messageBoxText = $"У вас недовес тела на = {Math.Abs(znacen_vesBr - Ves)} кг\nОжирение 3 степени";                              //Параментры для уведомления          //
                result = MessageBox.Show(messageBoxText, caption, button, icon);                                                                       //Возвращение Результатов уведомления //
            }                                                                                                                                          //                                    //
            else if (Ves.ToString() == znacen_vesBr.ToString() && znacen_Ket >= 40)                                                                    //Проверка условий                    //
            {                                                                                                                                          //                                    //
                string messageBoxText = "У вас оптимальный вес тела\nОжирение 3 степени";                                                              //Параментры для уведомления          //
                result = MessageBox.Show(messageBoxText, caption, button, icon);                                                                       //Возвращение Результатов уведомления //
            }                                                                                                                                          //                                    //
            else if (znacen_vesBr < Ves && znacen_Ket >= 40)                                                                                           //Проверка условий                    //
            {                                                                                                                                          //                                    //
                string messageBoxText = $"Ваш вес привышает оптимальный на = {Math.Abs(Ves - znacen_vesBr)} кг\nОжирение 3 степени";                   //Параментры для уведомления          //
                result = MessageBox.Show(messageBoxText, caption, button, icon);                                                                       //Возвращение Результатов уведомления //
            }                                                                                                                                          //                                    //
        }                                                                                                                                              //                                    //
    }                                                                                                                                                  //                                    //
}                                                                                                                                                      //                                    //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////